function AudioFileController(audiofileService) {
    var vm = this;

    vm.$onInit = $onInit;
    vm.showlist= showlist
    vm.showError = showError;

    function $onInit() {
        // vm.notesController will be our parent controller (NotesController)
        // vm.data will contain the data of this note
        vm.showlist();
    }
    function showlist() {
        return audiofileService.update(vm.data.id,title)

    }
    function showError(response) {
        alert(response.data.errors.join("\n"));
    }
}