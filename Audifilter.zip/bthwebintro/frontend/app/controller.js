var app=angular.module('app',[]);

app.controller('Name',function ($scope,$http) {
$http.get('http://localhost:8080/api/audiofiles/')
    .success(function (response) {
        $scope.Names=response.audiofile;
    })
});