angular.module('app', ['ngRoute'])
    .factory('audiofileService', audiofileService)

    .component('audiofile', {
        templateUrl: 'app/note/audiofile.tpl',
        controller: AudioFileController,
        controllerAs: 'vm',

    })
    .component('navigation', { templateUrl: 'app/navigation/navigation.tpl' })
    .component('info', { templateUrl: 'app/info/info.tpl' })
    .config(appConfig);