function appConfig($routeProvider) {
    $routeProvider
        .when('/', { template: '<audiofile></audiofile>' })
        .when('/info', { template: '<info></info>' })
        .otherwise({
            redirectTo: '/'
        })
}