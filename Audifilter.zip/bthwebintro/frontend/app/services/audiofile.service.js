function audiofileService($http, $interpolate) {
    var audiofiles = $interpolate('/api/audiofiles/{{id}}');

    return {
        list: list
    };

    function list() {
        return $http.get(audiofiles());
    }
}
