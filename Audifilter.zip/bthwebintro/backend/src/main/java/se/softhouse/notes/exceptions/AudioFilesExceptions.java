package se.softhouse.notes.exceptions;
import java.util.function.Supplier;

public enum AudioFilesExceptions implements Supplier<RuntimeException> {
    BAD_REQUEST(with(400, "Bad request to resource")), //
    NOT_AUTHORIZED(with(401, "Unauthorized")), //
    FORBIDDEN(with(403, "Unauthorized")), //
    NOT_FOUND(with(404, "Resource not found")), //
    FATAL(new RuntimeException()), //
    NOT_IMPLEMENTED(with(501, "Not implemented yet"));


    private RuntimeException runtimeException;

    AudioFilesExceptions(RuntimeException exception) {
        this.runtimeException = exception;
    }

    private static AudioFilesException with(Integer statusCode) {
        return new AudioFilesException(statusCode);
    }

    private static AudioFilesException with(Integer statusCode, String message) {
        return new AudioFilesException(message, statusCode);
    }

    public void raise() {
        throw runtimeException;
    }

    public void raise(String errorMessageFormat, Object... objects) {
        throw new AudioFilesException(String.format(errorMessageFormat, objects), runtimeException);
    }

    @Override
    public RuntimeException get() {
        return runtimeException;
    }
}

