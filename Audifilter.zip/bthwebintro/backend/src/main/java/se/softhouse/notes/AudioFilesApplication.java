package se.softhouse.notes;
import com.bazaarvoice.dropwizard.assets.ConfiguredAssetsBundle;
import io.dropwizard.Application;
import io.dropwizard.jdbi.DBIFactory;
import io.dropwizard.setup.Bootstrap;
import io.dropwizard.setup.Environment;
import org.skife.jdbi.v2.DBI;
import se.softhouse.notes.db.AudioFilesDAO;
import se.softhouse.notes.resources.AudioFilesResource;
import se.softhouse.notes.services.AudioFilesService;
import se.softhouse.notes.services.impl.AudioFilesServiceDbImpl;
public class AudioFilesApplication extends Application<AudioFilesConfiguration> {
    @Override
    public void run(AudioFilesConfiguration configuration, Environment environment) throws Exception {
        // setup database connection
        final DBI dbi = getDbiFor(configuration, environment);

        // data access objects
        final AudioFilesDAO audioFilesDAO = dbi.onDemand(AudioFilesDAO.class);
        audioFilesDAO.createTable();

        // services
        final AudioFilesService audioFilesService = new AudioFilesServiceDbImpl(audioFilesDAO);

        // resources
        final AudioFilesResource audioFilesResource = new AudioFilesResource(audioFilesService);

        // environment
        environment.jersey().register(audioFilesResource);
    }

    private DBI getDbiFor(AudioFilesConfiguration configuration, Environment environment) {
        return new DBIFactory().build(environment, configuration.getDataSourceFactory(), "sqlite");
    }

    @Override
    public void initialize(Bootstrap<AudioFilesConfiguration> configuration) {
        configuration.addBundle(new ConfiguredAssetsBundle("/assets/", "/", "index.html"));
    }

    public static void main(String[] args) throws Exception {
        new AudioFilesApplication().run(args);
    }
}

