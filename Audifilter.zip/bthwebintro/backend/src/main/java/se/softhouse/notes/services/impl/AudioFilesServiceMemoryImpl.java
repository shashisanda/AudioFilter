package se.softhouse.notes.services.impl;

import se.softhouse.notes.db.AudioFilesDAO;
import se.softhouse.notes.db.entity.AudioFile;
import se.softhouse.notes.services.AudioFilesService;

import java.util.List;

public class AudioFilesServiceMemoryImpl implements AudioFilesService {
    protected final AudioFilesDAO audioFilesDAO;

    public AudioFilesServiceMemoryImpl(AudioFilesDAO audioFilesDAO) {
        this.audioFilesDAO = audioFilesDAO;
    }

    public List<AudioFile> getAudioFiles() { return audioFilesDAO.selectAll();
    }

    @Override
    public void createAudioFile(AudioFile audioFile) {

    }

    @Override
    public AudioFile getAudioFileBy(int id) {
        return null;
    }

    @Override
    public void updateAudioFile(AudioFile audioFile) {

    }
}
