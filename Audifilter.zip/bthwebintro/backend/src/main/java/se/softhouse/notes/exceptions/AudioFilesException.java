package se.softhouse.notes.exceptions;

import javax.ws.rs.WebApplicationException;

public class AudioFilesException extends WebApplicationException {
    public AudioFilesException(int status) {
        super(status);
    }

    public AudioFilesException(String message, int status) {
        super(message, status);
    }

    public AudioFilesException(String message, Throwable cause) {
        super(message, cause);
    }
}
