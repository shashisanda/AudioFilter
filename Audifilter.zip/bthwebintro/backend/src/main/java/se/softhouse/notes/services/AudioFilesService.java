package se.softhouse.notes.services;

import se.softhouse.notes.db.entity.AudioFile;

import java.util.List;
public interface AudioFilesService {
    List<AudioFile> getAudioFiles();
    void createAudioFile(AudioFile audioFile);

    AudioFile getAudioFileBy(int id);

    void updateAudioFile(AudioFile audioFile);
}
