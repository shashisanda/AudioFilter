package se.softhouse.notes.services.impl;
import se.softhouse.notes.db.AudioFilesDAO;
import se.softhouse.notes.db.entity.AudioFile;
import se.softhouse.notes.exceptions.AudioFilesExceptions;
import se.softhouse.notes.services.AudioFilesService;

import java.util.List;

public class AudioFilesServiceDbImpl implements AudioFilesService {
    private final AudioFilesDAO audioFilesDAO;

    public AudioFilesServiceDbImpl(AudioFilesDAO audioFilesDAO) {
        this.audioFilesDAO = audioFilesDAO;
    }

    @Override
    public List<AudioFile> getAudioFiles() {
        return audioFilesDAO.selectAll();
    }

    @Override
    public void createAudioFile(AudioFile audioFile) {

    }

    @Override
    public AudioFile getAudioFileBy(int id) {
        return audioFilesDAO.get(id).orElseThrow(AudioFilesExceptions.NOT_FOUND);
    }

    @Override
    public void updateAudioFile(AudioFile audioFile) {

    }
}

