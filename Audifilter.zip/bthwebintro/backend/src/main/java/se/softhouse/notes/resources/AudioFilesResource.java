package se.softhouse.notes.resources;

import se.softhouse.notes.db.entity.AudioFile;
import se.softhouse.notes.services.AudioFilesService;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import java.util.List;

@Path("/audiofiles")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class AudioFilesResource {
    private final AudioFilesService audioFilesService;

    public AudioFilesResource(AudioFilesService audioFilesService) {
        this.audioFilesService = audioFilesService;
    }

    @GET
    public List<AudioFile> getAudioFiles() {
        return audioFilesService.getAudioFiles();
    }
}
