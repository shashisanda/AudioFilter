package se.softhouse.notes.db;


import org.skife.jdbi.v2.sqlobject.Bind;
import org.skife.jdbi.v2.sqlobject.BindBean;
import org.skife.jdbi.v2.sqlobject.SqlQuery;
import org.skife.jdbi.v2.sqlobject.SqlUpdate;
import org.skife.jdbi.v2.sqlobject.customizers.RegisterMapperFactory;
import org.skife.jdbi.v2.sqlobject.customizers.SingleValueResult;
import org.skife.jdbi.v2.tweak.BeanMapperFactory;
import se.softhouse.notes.db.entity.AudioFile;

import java.util.List;
import java.util.Optional;

@RegisterMapperFactory(BeanMapperFactory.class)
public interface AudioFilesDAO {
    @SqlUpdate("CREATE TABLE IF NOT EXISTS `audiofile`(id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, " + //
            "title VARCHAR NOT NULL)")
    void createTable();

    @SqlQuery("SELECT * FROM `audiofile`")
    List<AudioFile> selectAll();

    @SqlQuery("SELECT * FROM `audiofile` WHERE id = :id")
    @SingleValueResult
    Optional<AudioFile> get(@Bind("id") int id);
}
